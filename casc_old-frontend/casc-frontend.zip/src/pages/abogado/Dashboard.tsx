import { Typography } from '@mui/material';

export default function AbogadoDashboard() {
  return (
    <div>
      <Typography variant="h4">Panel del Abogado</Typography>
      {/* Contenido del dashboard aquí */}
    </div>
  );
}