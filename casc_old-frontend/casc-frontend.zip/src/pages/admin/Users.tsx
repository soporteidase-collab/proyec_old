import { Typography } from '@mui/material';

export default function Users() {
  return (
    <div>
      <Typography variant="h4">Gestión de Usuarios</Typography>
      {/* Contenido de la página */}
    </div>
  );
}